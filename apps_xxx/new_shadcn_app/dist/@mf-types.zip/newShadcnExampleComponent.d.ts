export * from './compiled-types/src/newShadcnExampleComponent';
export { default } from './compiled-types/src/newShadcnExampleComponent';