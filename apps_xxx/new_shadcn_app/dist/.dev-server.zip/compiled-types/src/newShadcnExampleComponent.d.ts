export declare function newShadcnExampleComponent(): import("react/jsx-runtime").JSX.Element;
